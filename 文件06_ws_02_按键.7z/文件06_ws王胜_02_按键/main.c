#include "common_inc.h"

void main_init(void);
//******************************
int main(void)
{
	main_init();
	while(1)
	{
		led_mainloop();
	}
}
//*******************************
void main_init(void)
{
	SYSCFG_DL_init(); //оƬ��Դ��ʼ��,��SysConfig���������Զ�����
	time_init();      //��ʱ���ж�
	key_init();       //������ʼ��
}
//******************************
//��������(��˫��)
void ComKey_MultipleClickCallback(comkey_t *key) 
{
	if (key->clickCnt == 1)//����
	{
		if(key == &Key_1)
		{
            DL_GPIO_clearPins(GPIO_LEDS_PORT_PORT,GPIO_LEDS_PORT_USER_LED_1_PIN);
		}
		if(key == &Key_2)
		{
            DL_GPIO_setPins(GPIO_RGB_PORT,GPIO_RGB_RED_PIN);
		}
		if(key == &Key_3)
		{
            DL_GPIO_setPins(GPIO_RGB_PORT,GPIO_RGB_GREEN_PIN);
		}
	}
	if (key->clickCnt == 2) //˫��
	{
		if(key == &Key_1)
		{
            DL_GPIO_setPins(GPIO_LEDS_PORT_PORT,GPIO_LEDS_PORT_USER_LED_1_PIN);
		}
		if(key == &Key_2)
		{
            DL_GPIO_clearPins(GPIO_RGB_PORT,GPIO_RGB_RED_PIN);
		}
		if(key == &Key_3)
		{
            DL_GPIO_clearPins(GPIO_RGB_PORT,GPIO_RGB_GREEN_PIN);
		}
	}
}

