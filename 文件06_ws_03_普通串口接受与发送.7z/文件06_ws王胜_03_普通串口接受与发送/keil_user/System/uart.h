#ifndef _UART_H
#define _UART_H
#include "common_inc.h"


void uart_init(void);



void usart0_send_bytes(u8 *buf, int len);





#endif 







