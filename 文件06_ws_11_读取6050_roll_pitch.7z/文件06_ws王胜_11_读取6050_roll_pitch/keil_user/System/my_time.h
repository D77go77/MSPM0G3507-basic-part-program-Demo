
#ifndef _TIME_H
#define _TIME_H
#include "common_inc.h"



void time_init(void);

extern u8 f_500ms_led;
extern u8 f_100ms_oled;
extern u8 f_10ms_key;
extern u8 f_50ms_mpu6050;
extern u8 f_5ms_beep;

#endif 







