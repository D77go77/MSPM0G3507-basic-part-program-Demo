#ifndef _MY_PWM_H
#define _MY_PWM_H
#include "common_inc.h"

#define CHANNEL0 0
#define CHANNEL1 1
#define CHANNEL2 2
#define CHANNEL3 3

#define LEFT 1  //��
#define RIGHT 0 //��

typedef struct PWM
{
	//ͨ��
	u8 IN1_channel;
	u8 IN2_channel;
	
	//ռ�ձ�
	float duty;
}PWM;

extern PWM pwm0_left,pwm0_right;

void Struct_PWM_init(PWM *pwm,u8 IN1_channel,u8 IN2_channel);

extern float pwm_pulse;


void pwm_init(void);

void set_PWM0_duty(float duty,u8 channel);

float abs_float(float num);

void set_Wheels(PWM *pwm, float duty);



#endif