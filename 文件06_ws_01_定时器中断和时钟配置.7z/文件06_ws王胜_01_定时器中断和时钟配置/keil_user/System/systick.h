#ifndef SYS_TICK_H
#define SYS_TICK_H

#include "common_inc.h"

void delay_ms(uint32_t ms);






#endif /* SYS_TICK_H */







