#include "common_inc.h"

void main_init(void);
//******************************
int main(void)
{
	main_init();
	while(1)
	{
		led_mainloop();
		oled_mainloop();
		adc_mainloop();
		beep_mainloop(&beep);
		mpu6050_mainloop();
	}
}
//*******************************
void main_init(void)
{
	//
	SYSCFG_DL_init(); 	//оƬ��Դ��ʼ��,��SysConfig���������Զ�����
	time_init();      	//��ʱ���ж�
	key_init();       	//������ʼ��
	oled_init();		//oled��ʾ����ʼ��
	adc_init();			//ADC��ʼ��
	encoder_init();		//��������ʼ��
	pwm_init();			//�����ʼ��
	spwm_init();      	//��ʼ�����
	beep_init();		//��������ʼ��
	mpu6050_init();		//mpu6050��ʼ��
}
//******************************
//��������(��˫��)
void ComKey_MultipleClickCallback(comkey_t *key) 
{
	if (key->clickCnt == 1)//����
	{
		if(key == &Key_1)
		{
            DL_GPIO_clearPins(GPIO_LEDS_PORT_PORT,GPIO_LEDS_PORT_USER_LED_1_PIN);
			set_Wheels(&pwm0_right,0.5); //����ǰ��50%ռ�ձ�
		}
		if(key == &Key_2)
		{
            DL_GPIO_setPins(GPIO_RGB_PORT,GPIO_RGB_RED_PIN);
			set_Wheels(&pwm0_left,0.5);
		}
		if(key == &Key_3)
		{
            DL_GPIO_setPins(GPIO_RGB_PORT,GPIO_RGB_GREEN_PIN);
			set_Wheels(&pwm0_left,0);  set_Wheels(&pwm0_right,0);
		}
		if(key == &Key_D3_5)
		{
				DL_GPIO_clearPins(GPIO_LEDS_PORT_PORT,GPIO_LEDS_PORT_USER_LED_1_PIN);
			
				servo_angle+=10;
				if(servo_angle>90) servo_angle=-90;
				set_Servo_angle(&spwm0,servo_angle);
		}
		if(key == &Key_D3_1)
		{
				DL_GPIO_setPins(GPIO_RGB_PORT,GPIO_RGB_RED_PIN);
		}
		if(key == &Key_D3_2)
		{
				DL_GPIO_setPins(GPIO_RGB_PORT,GPIO_RGB_GREEN_PIN);
		}
		if(key == &Key_D3_3)
		{
				DL_GPIO_setPins(GPIO_RGB_PORT,GPIO_RGB_BLUE_PIN);
		}
		if(key == &Key_D3_4)
		{
				DL_GPIO_clearPins(GPIO_LEDS_PORT_PORT,GPIO_LEDS_PORT_USER_LED_1_PIN);
		}
	}
	if (key->clickCnt == 2) //˫��
	{
		if(key == &Key_1)
		{
            DL_GPIO_setPins(GPIO_LEDS_PORT_PORT,GPIO_LEDS_PORT_USER_LED_1_PIN);
			set_Wheels(&pwm0_right,-0.5); //���ֺ��20%ռ�ձ�
		}
		if(key == &Key_2)
		{
            DL_GPIO_clearPins(GPIO_RGB_PORT,GPIO_RGB_RED_PIN);
			set_Wheels(&pwm0_left,-0.5);
		}
		if(key == &Key_3)
		{
            DL_GPIO_clearPins(GPIO_RGB_PORT,GPIO_RGB_GREEN_PIN);
		}
	}
}
//
void ComKey_HoldTriggerCallback(comkey_t *key)
{

	if(key == &Key_1)
	{
			DL_GPIO_clearPins(GPIO_LEDS_PORT_PORT,GPIO_LEDS_PORT_USER_LED_1_PIN);
	}
	if(key == &Key_2)
	{
			DL_GPIO_setPins(GPIO_RGB_PORT,GPIO_RGB_RED_PIN);
	}
	if(key == &Key_3)
	{
			DL_GPIO_setPins(GPIO_RGB_PORT,GPIO_RGB_GREEN_PIN);
	}
}
