# 重新修改时钟数为40Mhz

## 1.syscfg配置

从左到右一步一步配置

![image-20240708215603721](https://z1r343l-001.obs.cn-north-4.myhuaweicloud.com/ws_C301/image-20240708215603721.png)

依次，输入40 ✔20✔

![image-20240708215716138](https://z1r343l-001.obs.cn-north-4.myhuaweicloud.com/ws_C301/image-20240708215716138.png)

中段配置

![image-20240708215757628](https://z1r343l-001.obs.cn-north-4.myhuaweicloud.com/ws_C301/image-20240708215757628.png)

后上端

![image-20240708215821304](https://z1r343l-001.obs.cn-north-4.myhuaweicloud.com/ws_C301/image-20240708215821304.png)

后下端

![image-20240708215834197](https://z1r343l-001.obs.cn-north-4.myhuaweicloud.com/ws_C301/image-20240708215834197.png)

因为时钟变了，要修改pwm的频率来达到我们需要的频率

![image-20240708215951917](https://z1r343l-001.obs.cn-north-4.myhuaweicloud.com/ws_C301/image-20240708215951917.png)

![image-20240708220007502](https://z1r343l-001.obs.cn-north-4.myhuaweicloud.com/ws_C301/image-20240708220007502.png)
