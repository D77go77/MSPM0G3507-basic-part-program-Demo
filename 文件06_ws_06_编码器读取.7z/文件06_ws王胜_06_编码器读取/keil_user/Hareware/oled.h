#ifndef __OLED_H
#define __OLED_H

#include "common_inc.h"
#include "drv_oled.h"

void oled_mainloop();

#endif




