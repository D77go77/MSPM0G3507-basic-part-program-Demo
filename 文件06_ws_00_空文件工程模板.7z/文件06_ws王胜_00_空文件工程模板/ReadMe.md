# 本文件为模板工程

方便区分管理，自己写的新文件放在keil_users里

![image-20240705220425182](https://z1r343l-001.obs.cn-north-4.myhuaweicloud.com/ws_C301/image-20240705220425182.png)

![image-20240705220434197](https://z1r343l-001.obs.cn-north-4.myhuaweicloud.com/ws_C301/image-20240705220434197.png)

keil_project格式如下

![image-20240705220443604](https://z1r343l-001.obs.cn-north-4.myhuaweicloud.com/ws_C301/image-20240705220443604.png)

![image-20240705221439721](https://z1r343l-001.obs.cn-north-4.myhuaweicloud.com/ws_C301/image-20240705221439721.png)
